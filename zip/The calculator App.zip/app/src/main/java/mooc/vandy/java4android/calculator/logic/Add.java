package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Add operation.
 */
public class Add {
    public int addition(int a,int b){
        return a+b;
    }
}
