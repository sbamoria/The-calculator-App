package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Multiply operation.
 */
public class Multiply {
    public int multiplication(int a,int b){
        return a*b;
    }
}
