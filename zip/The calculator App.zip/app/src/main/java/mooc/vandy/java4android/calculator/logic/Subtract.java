package mooc.vandy.java4android.calculator.logic;

/**
 * Perform the Subtract operation.
 */
public class Subtract {
    public int subtraction(int a,int b){
        return a-b;
    }
}
